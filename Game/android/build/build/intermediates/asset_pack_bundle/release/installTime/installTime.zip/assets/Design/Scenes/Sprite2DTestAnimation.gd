extends Sprite2D

var d = 0.0
var radius = 250
var speed = 5

# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	d += delta
	position = Vector2(sin(d * speed) * radius,cos(d * speed) * radius) #+ get_parent().position
